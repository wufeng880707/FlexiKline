// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'candle_req.dart';

// **************************************************************************
// CopyWithGenerator
// **************************************************************************

abstract class _$CandleReqCWProxy {
  CandleReq instId(String instId);

  CandleReq timeBar(TimeBarConfig timeBar);

  CandleReq limit(int limit);

  CandleReq precision(int precision);

  CandleReq after(int? after);

  CandleReq before(int? before);

  CandleReq state(RequestState state);

  /// This function **does support** nullification of nullable fields. All `null` values passed to `non-nullable` fields will be ignored. You can also use `CandleReq(...).copyWith.fieldName(...)` to override fields one at a time with nullification support.
  ///
  /// Usage
  /// ```dart
  /// CandleReq(...).copyWith(id: 12, name: "My name")
  /// ````
  CandleReq call({
    String? instId,
    TimeBarConfig? timeBar,
    int? limit,
    int? precision,
    int? after,
    int? before,
    RequestState? state,
  });
}

/// Proxy class for `copyWith` functionality. This is a callable class and can be used as follows: `instanceOfCandleReq.copyWith(...)`. Additionally contains functions for specific fields e.g. `instanceOfCandleReq.copyWith.fieldName(...)`
class _$CandleReqCWProxyImpl implements _$CandleReqCWProxy {
  const _$CandleReqCWProxyImpl(this._value);

  final CandleReq _value;

  @override
  CandleReq instId(String instId) => this(instId: instId);

  @override
  CandleReq timeBar(TimeBarConfig timeBar) => this(timeBar: timeBar);

  @override
  CandleReq limit(int limit) => this(limit: limit);

  @override
  CandleReq precision(int precision) => this(precision: precision);

  @override
  CandleReq after(int? after) => this(after: after);

  @override
  CandleReq before(int? before) => this(before: before);

  @override
  CandleReq state(RequestState state) => this(state: state);

  @override

  /// This function **does support** nullification of nullable fields. All `null` values passed to `non-nullable` fields will be ignored. You can also use `CandleReq(...).copyWith.fieldName(...)` to override fields one at a time with nullification support.
  ///
  /// Usage
  /// ```dart
  /// CandleReq(...).copyWith(id: 12, name: "My name")
  /// ````
  CandleReq call({
    Object? instId = const $CopyWithPlaceholder(),
    Object? timeBar = const $CopyWithPlaceholder(),
    Object? limit = const $CopyWithPlaceholder(),
    Object? precision = const $CopyWithPlaceholder(),
    Object? after = const $CopyWithPlaceholder(),
    Object? before = const $CopyWithPlaceholder(),
    Object? state = const $CopyWithPlaceholder(),
  }) {
    return CandleReq(
      instId: instId == const $CopyWithPlaceholder() || instId == null
          ? _value.instId
          // ignore: cast_nullable_to_non_nullable
          : instId as String,
      timeBar: timeBar == const $CopyWithPlaceholder() || timeBar == null
          ? _value.timeBar
          // ignore: cast_nullable_to_non_nullable
          : timeBar as TimeBarConfig,
      limit: limit == const $CopyWithPlaceholder() || limit == null
          ? _value.limit
          // ignore: cast_nullable_to_non_nullable
          : limit as int,
      precision: precision == const $CopyWithPlaceholder() || precision == null
          ? _value.precision
          // ignore: cast_nullable_to_non_nullable
          : precision as int,
      after: after == const $CopyWithPlaceholder()
          ? _value.after
          // ignore: cast_nullable_to_non_nullable
          : after as int?,
      before: before == const $CopyWithPlaceholder()
          ? _value.before
          // ignore: cast_nullable_to_non_nullable
          : before as int?,
      state: state == const $CopyWithPlaceholder() || state == null
          ? _value.state
          // ignore: cast_nullable_to_non_nullable
          : state as RequestState,
    );
  }
}

extension $CandleReqCopyWith on CandleReq {
  /// Returns a callable class that can be used as follows: `instanceOfCandleReq.copyWith(...)` or like so:`instanceOfCandleReq.copyWith.fieldName(...)`.
  // ignore: library_private_types_in_public_api
  _$CandleReqCWProxy get copyWith => _$CandleReqCWProxyImpl(this);
}

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

CandleReq _$CandleReqFromJson(Map<String, dynamic> json) => CandleReq(
      instId: json['instId'] as String,
      timeBar: TimeBarConfig.fromJson(json['timeBar'] as Map<String, dynamic>),
      limit: (json['limit'] as num?)?.toInt() ?? 100,
      after: (json['after'] as num?)?.toInt(),
      before: (json['before'] as num?)?.toInt(),
    );

Map<String, dynamic> _$CandleReqToJson(CandleReq instance) => <String, dynamic>{
      'instId': instance.instId,
      if (instance.after case final value?) 'after': value,
      if (instance.before case final value?) 'before': value,
      'timeBar': instance.timeBar.toJson(),
      'limit': instance.limit,
    };
