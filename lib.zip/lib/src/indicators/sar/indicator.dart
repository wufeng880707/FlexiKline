// Copyright 2024 Andy.Zhao
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     https://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

part of 'sar.dart';

/// SAR 抛物线指标
/// SAR 的计算需要参考每一日的最高价与最低价：
/// SAR(今日)：SAR (昨日) + AF (动能趋势指标) x [ (区间极值(波段内最极值) – SAR(昨日)]
@CopyWith()
@FlexiIndicatorSerializable
class SARIndicator extends PaintObjectIndicator implements IPrecomputable {
  SARIndicator({
    super.zIndex = 0,
    required super.height,
    super.padding = defaultMainIndicatorPadding,

    /// SAR计算参数
    this.calcParam = const SARParam(startAf: 0.02, step: 0.02, maxAf: 0.2),

    /// 绘制相关参数
    this.radius,
    this.useCandleColor = true,
    required this.paint,
    required this.tipsPadding,
    required this.tipsStyle,
    this.tickCount = defaultSubTickCount,
  }) : super(key: const FlexiIndicatorKey('sar'));

  /// SAR计算参数
  @override
  final SARParam calcParam;

  /// 圆的半径.
  /// 注: 如果为空, 将取蜡烛宽度的1/3, 随着缩放操作自动变化大小.
  final double? radius;

  /// 绘制SAR的画笔.
  final PaintConfig paint;

  /// SAR画笔颜色是否使用蜡烛色, 如果设置为true, 则[paint]中的color配置无效.
  final bool useCandleColor;
  final EdgeInsets tipsPadding;
  final TextStyle tipsStyle;

  /// YAxis刻度数量(注: 仅在key为subSarKey时有用)
  final int tickCount;

  @override
  PaintObjectBox createPaintObject(
    IPaintContext context, {
    KlineEventBus? eventBus,
  }) {
    return SARPaintObject(context: context, indicator: this);
  }

  factory SARIndicator.fromJson(Map<String, dynamic> json) => _$SARIndicatorFromJson(json);

  @override
  Map<String, dynamic> toJson() => _$SARIndicatorToJson(this);
}

class SARPaintObject<T extends SARIndicator> extends PaintObjectBox<T>
    with SarDataMixin, PaintYAxisTicksMixin, PaintYAxisTicksOnCrossMixin, PaintSimpleCandleMixin {
  SARPaintObject({
    required super.context,
    required super.indicator,
  });

  bool? _isInsub;
  bool get isInSub => _isInsub ??= indicator.key == const FlexiIndicatorKey('sar');

  @override
  MinMax? initState(int start, int end) {
    if (!klineData.canPaintChart) return null;

    MinMax? sarMinmax = calcuSarMinmax(
      indicator.calcParam,
      start: start,
      end: end,
    );
    if (isInSub) {
      MinMax? candleMinmax = klineData.calculateMinmax(start, end);
      if (candleMinmax != null) return candleMinmax..updateMinMax(sarMinmax);
      if (sarMinmax != null) return sarMinmax..updateMinMax(candleMinmax);
      return null;
    } else {
      return sarMinmax;
    }
  }

  @override
  void paintChart(Canvas canvas, Size size) {
    /// 绘制SAR图
    paintSarChart(canvas, size);

    if (isInSub && settingConfig.showYAxisTick) {
      paintYAxisTicks(
        canvas,
        size,
        tickCount: indicator.tickCount,
        precision: klineData.precision,
      );
    }
  }

  /// 重写[paintYAxisTicks]中的格式化刻度值.
  @override
  String fromatTicksValue(BagNum value, {required int precision}) {
    return formatPrice(
      value.toDecimal(),
      precision: precision,
      cutInvalidZero: false,
      showThousands: true,
    );
  }

  @override
  void onCross(Canvas canvas, Offset offset) {
    /// onCross时, 绘制Y轴上的标记值(注: 仅对indicator.key为subSarKey时有效)
    if (isInSub) {
      paintYAxisTicksOnCross(
        canvas,
        offset,
        precision: klineData.precision,
      );
    }
  }

  /// 在onCross时, 重写[paintYAxisTicksOnCross]中的格式化刻度值
  @override
  String formatTicksValueOnCross(BagNum value, {required int precision}) {
    return formatPrice(
      value.toDecimal(),
      precision: precision,
      cutInvalidZero: false,
      showThousands: true,
    );
  }

  void paintSarChart(Canvas canvas, Size size) {
    if (!klineData.canPaintChart) return;
    final list = klineData.list;
    final len = list.length;
    if (!indicator.calcParam.isValid(len)) return;
    int start = klineData.start;
    int end = (klineData.end + 1).clamp(start, len); // 多绘制一根蜡烛

    if (isInSub) {
      // 绘制简易蜡烛
      paintSimpleCandleChart(canvas, size);
    }

    Paint paint = indicator.paint.paint;
    final radius = indicator.radius ?? candleActualWidth / 3;

    final offset = startCandleDx - candleWidthHalf;
    CandleModel m;
    for (int i = start; i < end; i++) {
      m = list[i];
      if (!m.isValidSarData) continue;
      final dx = offset - (i - start) * candleActualWidth;
      if (indicator.useCandleColor) {
        if (m.sarFlag! > 0) {
          paint.color = settingConfig.longColor;
        } else if (m.sarFlag! < 0) {
          paint.color = settingConfig.shortColor;
        } else {
          paint.color = settingConfig.textColor;
        }
      }
      canvas.drawCircle(
        Offset(dx, valueToDy(m.sar!, correct: false)),
        radius,
        paint,
      );
    }
  }

  @override
  Size? paintTips(
    Canvas canvas, {
    CandleModel? model,
    Offset? offset,
    Rect? tipsRect,
  }) {
    model ??= offsetToCandle(offset);
    if (model == null || !model.isValidSarData) return null;

    final text = formatNumber(
      model.sar?.toDecimal(),
      precision: klineData.precision,
      showThousands: true,
      cutInvalidZero: true,
      prefix: 'SAR: ',
    );

    tipsRect ??= drawableRect;
    return canvas.drawText(
      offset: tipsRect.topLeft,
      text: text,
      style: indicator.tipsStyle,
      drawDirection: DrawDirection.ltr,
      drawableRect: tipsRect,
      textAlign: TextAlign.left,
      padding: indicator.tipsPadding,
      maxLines: 1,
    );
  }
}
